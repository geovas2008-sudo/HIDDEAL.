import React from 'react';
import {
	Accordion,
	AccordionContent,
	AccordionItem,
	AccordionTrigger,
} from '@/components/ui/accordion';

interface Question {
    id: string;
    title: string;
    content: string;
}

interface FaqsSectionProps {
    questions: Question[];
    title?: string;
    description?: string;
}

export function FaqsSection({ questions, title = "Preguntas Frecuentes", description = "Resolvemos tus dudas antes de empezar." }: FaqsSectionProps) {
	return (
		<div className="mx-auto w-full max-w-3xl space-y-7 pt-16">
			<div className="space-y-2 text-center">
				<h2 className="text-3xl font-bold md:text-4xl tracking-tight">{title}</h2>
				<p className="text-muted-foreground max-w-2xl mx-auto">
					{description}
				</p>
			</div>
			<Accordion
				type="single"
				collapsible
				className="w-full -space-y-px"
				defaultValue="item-1"
			>
				{questions.map((item) => (
					<AccordionItem
						value={item.id}
						key={item.id}
						className="border border-white/10 bg-white/5 px-4 rounded-lg mb-4 data-[state=open]:bg-white/10 transition-colors"
					>
						<AccordionTrigger className="py-4 text-[15px] leading-6 hover:no-underline font-medium">
							{item.title}
						</AccordionTrigger>
						<AccordionContent className="text-muted-foreground pb-4 leading-relaxed">
							{item.content}
						</AccordionContent>
					</AccordionItem>
				))}
			</Accordion>
			<p className="text-muted-foreground text-center pt-8">
				¿No encuentras lo que buscas?{' '}
				<a href="#" className="text-primary hover:underline font-medium">
					Contáctanos directamente
				</a>
			</p>
		</div>
	);
}
