import React from 'react';

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-black text-white">
      {/* Background grid */}
      <div className="absolute inset-0 
        bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)]
        bg-[size:40px_40px]
        [mask-image:radial-gradient(circle_at_center,black,transparent_75%)]">
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-6 pt-20 pb-10">
        {/* TOP GRID */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-16">
          {/* BRAND */}
          <div className="md:col-span-5 flex flex-col gap-6">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 bg-primary rotate-45"></div>
              <h2 className="text-2xl font-bold tracking-tight">HIDDEAL</h2>
            </div>

            <p className="text-sm text-gray-400 max-w-sm leading-relaxed">
              Construimos sistemas de crecimiento para clínicas.
              Convertimos mensajes en citas y citas en pacientes constantes.
            </p>

            {/* CTAs */}
            <div className="flex gap-3 mt-4 flex-wrap">
              <a href="#agendar"
                className="flex items-center gap-2 bg-primary px-5 py-2 rounded-lg text-sm font-medium hover:opacity-90 transition">
                Agendar llamada
                <span>→</span>
              </a>

              <a href="https://api.whatsapp.com/send/?phone=5579517911&text&type=phone_number&app_absent=0"
                className="flex items-center gap-2 border border-white/20 px-5 py-2 rounded-lg text-sm hover:bg-white/5 transition">
                WhatsApp
              </a>
            </div>
          </div>

          {/* LINKS */}
          <div className="md:col-span-2">
            <h4 className="mb-4 text-xs uppercase tracking-widest text-gray-500">
              Qué hacemos
            </h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors">Sistema para clínicas</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">WhatsApp & seguimiento</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Conversión a citas</a></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="mb-4 text-xs uppercase tracking-widest text-gray-500">
              Empresa
            </h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors">Sobre HIDDEAL</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Proceso</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Preguntas frecuentes</a></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="mb-4 text-xs uppercase tracking-widest text-gray-500">
              Contacto
            </h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#agendar" className="hover:text-primary transition-colors">Agendar llamada</a></li>
              <li><a href="tel:+52XXXXXXXXXX" className="hover:text-primary transition-colors">Llamar</a></li>
              <li><a href="https://api.whatsapp.com/send/?phone=5579517911&text&type=phone_number&app_absent=0" className="hover:text-primary transition-colors">WhatsApp</a></li>
            </ul>
          </div>
        </div>

        {/* BOTTOM BAR */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-t border-white/10 pt-6">
          <p className="text-xs text-gray-500">
            © 2026 HIDDEAL. Sistemas de crecimiento para clínicas.
          </p>

          <div className="flex gap-4 text-xs text-gray-400">
            <a href="tel:+52XXXXXXXXXX" className="hover:text-white transition-colors">Llamar</a>
            <a href="https://api.whatsapp.com/send/?phone=5579517911&text&type=phone_number&app_absent=0" className="hover:text-white transition-colors">WhatsApp</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
