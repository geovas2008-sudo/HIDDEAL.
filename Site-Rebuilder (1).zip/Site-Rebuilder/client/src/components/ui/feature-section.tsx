import { Badge } from "@/components/ui/badge";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Button } from "@/components/ui/button";
import { Phone, Calendar } from "lucide-react";

interface FeatureSectionProps {
  id: string;
  badge: string;
  title: string;
  description: string;
  images?: string[];
}

export function FeatureSection({ id, badge, title, description, images = [] }: FeatureSectionProps) {
  const whatsappUrl = "https://api.whatsapp.com/send/?phone=5579517911&text&type=phone_number&app_absent=0";
  const calendarUrl = "https://cal.com/giov-mfymyh/cita?user=giov-mfymyh&overlayCalendar=true";

  return (
    <div id={id} className="w-full py-20 lg:py-32 border-t border-white/5 scroll-mt-20">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 justify-end items-center gap-10">
          <div className="flex gap-6 flex-col items-start animate-in fade-in slide-in-from-left-8 duration-1000">
            <div>
              <Badge variant="outline" className="text-primary border-primary/30 px-3 py-1 uppercase tracking-widest text-[10px]">
                {badge}
              </Badge>
            </div>
            <div className="flex gap-4 flex-col">
              <h2 className="text-3xl md:text-5xl tracking-tighter lg:max-w-xl font-bold text-left leading-tight">
                {title}
              </h2>
              <p className="text-lg max-w-xl lg:max-w-md leading-relaxed tracking-tight text-muted-foreground text-left">
                {description}
              </p>
            </div>
            <div className="flex flex-wrap gap-4 pt-4">
              <Button 
                onClick={() => window.open(calendarUrl, "_blank")}
                className="rounded-full px-6 h-12 bg-primary hover:bg-primary/90 transition-all flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                Agendar Cita
              </Button>
              <Button 
                variant="outline"
                onClick={() => window.open(whatsappUrl, "_blank")}
                className="rounded-full px-6 h-12 border-white/10 hover:bg-white/5 transition-all flex items-center gap-2 text-white"
              >
                <Phone className="w-4 h-4" />
                Contactar
              </Button>
            </div>
          </div>
          <div className="w-full max-w-full px-6 lg:px-0 animate-in fade-in slide-in-from-right-8 duration-1000">
            <Carousel className="w-full">
              <CarouselContent>
                {(images.length > 0 ? images : [1, 2]).map((img, index) => (
                  <CarouselItem key={index}>
                    <div className="flex rounded-2xl aspect-video bg-neutral-900 border border-white/10 items-center justify-center overflow-hidden relative group">
                      {typeof img === "string" ? (
                        <img
                          src={img}
                          alt={`${title} visual ${index + 1}`}
                          className="h-full w-full object-cover"
                          data-testid={`img-service-visual-${id}-${index}`}
                        />
                      ) : (
                        <>
                          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-purple-900/20 opacity-50 group-hover:opacity-70 transition-opacity" />
                          <span className="text-sm text-white/40 font-mono uppercase tracking-widest relative z-10">
                            {title} Visual {index + 1}
                          </span>
                        </>
                      )}
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <div className="hidden sm:block">
                <CarouselPrevious className="bg-black/50 border-white/10 hover:bg-primary hover:text-white" />
                <CarouselNext className="bg-black/50 border-white/10 hover:bg-primary hover:text-white" />
              </div>
            </Carousel>
          </div>
        </div>
      </div>
    </div>
  );
}
