import { useParams, useLocation } from "wouter";
import { FeatureSection } from "@/components/ui/feature-section";
import { Footer } from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useEffect } from "react";

import anunciosMeta1 from "@assets/AnunciosMeta_1_1769621956862.jpg";
import anunciosMeta2 from "@assets/AnunciosMeta_2_1769621956863.jpg";
import brandingBasico1 from "@assets/BrandingBasico_1_1769621956863.jpg";
import brandingBasico2 from "@assets/BrandingBasico_2_1769621956864.jpg";
import chatbotAutomatizado1 from "@assets/ChatBotAutomatizado_1_1769621956864.jpg";
import chatbotAutomatizado2 from "@assets/ChatBotAutomatizado_2_1769621956865.jpg";
import fotosyVideos1 from "@assets/FotosyVideos_1_1769621956865.jpg";
import fotosyVideos2 from "@assets/FotosyVideos_2_1769621956866.jpg";
import googlemaps1 from "@assets/googlemaps_1_1769621956866.jpg";
import googlemaps2 from "@assets/googlemaps_2_1769621956867.jpg";
import paginaWeb1 from "@assets/PaginaWeb_1_1769621956867.jpg";
import paginaWeb2 from "@assets/PaginaWeb_2_1769621956868.jpg";
import recepcionistaVirtual1 from "@assets/RecepcionistaVirtual_1_1769621956868.jpg";
import recepcionistaVirtual2 from "@assets/RecepcionistaVirtual_2_1769621956869.jpg";
import sistemaResenas1 from "@assets/SistemadeReseñas_1_1769621956869.jpg";
import sistemaResenas2 from "@assets/SistemadeReseñas_2_1769621956869.jpg";

const serviceData: Record<string, { badge: string; title: string; description: string; images: string[] }> = {
  "google-maps": {
    badge: "Local SEO",
    title: "Google Maps",
    description: "Optimizamos tu perfil para que tu clínica aparezca cuando las personas buscan servicios como el tuyo en tu zona, mejorando visibilidad, confianza y llamadas directas.",
    images: [googlemaps1, googlemaps2],
  },
  "fotos-videos": {
    badge: "Producción",
    title: "Fotos y Videos",
    description: "Creamos fotos y videos reales y profesionales de tu clínica para transmitir confianza, mostrar tu espacio y aumentar la probabilidad de que te elijan frente a otras opciones.",
    images: [fotosyVideos1, fotosyVideos2],
  },
  "sistema-reseñas": {
    badge: "Reputación",
    title: "Sistema de Reseñas",
    description: "Implementamos un sistema automático para conseguir más reseñas positivas en Google, fortaleciendo tu reputación y haciendo que más pacientes confíen en tu clínica.",
    images: [sistemaResenas1, sistemaResenas2],
  },
  "anuncios-meta": {
    badge: "Marketing",
    title: "Anuncios Meta",
    description: "Creamos anuncios estratégicos que llegan a personas interesadas en tus servicios y las llevamos directamente a WhatsApp o a una cita agendada.",
    images: [anunciosMeta1, anunciosMeta2],
  },
  "pagina-web": {
    badge: "Digital",
    title: "Página Web",
    description: "Desarrollamos una página clara y optimizada para convertir visitas en mensajes o citas, explicando tu servicio de forma sencilla y profesional.",
    images: [paginaWeb1, paginaWeb2],
  },
  "branding-basico": {
    badge: "Identidad",
    title: "Branding Básico",
    description: "Unificamos colores, tipografías y estilo visual para que tu clínica se vea profesional, confiable y coherente en todos los canales digitales.",
    images: [brandingBasico1, brandingBasico2],
  },
  "recepcionista-virtual": {
    badge: "Operaciones",
    title: "Recepcionista Virtual",
    description: "Implementamos un sistema que atiende llamadas, filtra pacientes y agenda citas automáticamente, incluso cuando tu clínica está cerrada.",
    images: [recepcionistaVirtual1, recepcionistaVirtual2],
  },
  "chatbot-automatizado": {
    badge: "IA",
    title: "Chatbot Automatizado",
    description: "Creamos un chatbot que responde preguntas frecuentes, capta datos y guía a los interesados hasta agendar una cita sin intervención manual como si fuera un humano.",
    images: [chatbotAutomatizado1, chatbotAutomatizado2],
  }
};

export default function ServiceDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const service = id ? serviceData[id] : null;

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!service) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-4xl font-bold mb-4">Servicio no encontrado</h1>
        <Button onClick={() => setLocation("/")} variant="outline" className="rounded-full">
            <ArrowLeft className="mr-2 h-4 w-4" /> Volver al inicio
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/50 backdrop-blur-md border-b border-white/5 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Button onClick={() => setLocation("/")} variant="ghost" className="text-white hover:bg-white/10 rounded-full">
            <ArrowLeft className="mr-2 h-4 w-4" /> Volver
          </Button>
          <span className="font-bold tracking-tight text-xl">HIDDEAL</span>
        </div>
      </nav>

      <div className="pt-20">
        <FeatureSection 
          id={id!}
          badge={service.badge}
          title={service.title}
          description={service.description}
          images={service.images}
        />
      </div>

      <Footer />
    </div>
  );
}
