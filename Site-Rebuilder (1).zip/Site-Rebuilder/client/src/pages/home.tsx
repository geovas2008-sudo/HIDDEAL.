import { EtheralShadow } from "@/components/ui/etheral-shadow";
import { SpotlightCard } from "@/components/ui/spotlight-card";
import { UniqueAccordion } from "@/components/ui/interactive-accordion";
import { LetsWorkTogether } from "@/components/ui/lets-work-section";
import { FaqsSection } from "@/components/ui/faqs-1";
import { Footer } from "@/components/ui/footer";
import { ArrowUpRight, MessageSquareOff, CalendarX, TrendingDown, LayoutDashboard, Database, Smartphone, Globe, Camera, MapPin, Search } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();
  const problems = [
    {
      title: "No llegan pacientes",
      description: "El flujo de pacientes nuevos es inconsistente o insuficiente para mantener la clínica rentable.",
      icon: <TrendingDown className="h-6 w-6 text-red-400" />,
    },
    {
      title: "Mensajes perdidos",
      description: "Los mensajes de WhatsApp se pierden y nadie responde a tiempo, perdiendo oportunidades valiosas.",
      icon: <MessageSquareOff className="h-6 w-6 text-orange-400" />,
    },
    {
      title: "Agenda vacía",
      description: "Las citas no se llenan o dependen de recomendaciones al azar en lugar de un sistema predecible.",
      icon: <CalendarX className="h-6 w-6 text-yellow-400" />,
    },
  ];

  const processItems = [
    {
      id: "diagnostico",
      number: "01",
      title: "Diagnóstico y Objetivos",
      content: "Analizamos la situación actual de tu clínica, identificamos cuellos de botella y definimos objetivos claros de crecimiento.",
    },
    {
      id: "sistemas",
      number: "02",
      title: "Configuración de Sistemas",
      content: "Implementamos los sistemas de captación y seguimiento necesarios para automatizar procesos y asegurar que ningún paciente se pierda.",
    },
    {
      id: "contenido",
      number: "03",
      title: "Creación de Contenido",
      content: "Producimos fotos y videos profesionales del consultorio y equipo para generar confianza y autoridad antes de la primera visita.",
    },
    {
      id: "lanzamiento",
      number: "04",
      title: "Lanzamiento y Optimización",
      content: "Lanzamos campañas estratégicas y monitoreamos resultados diariamente para optimizar la inversión y maximizar las citas agendadas.",
    },
  ];

  const faqs = [
    {
      id: "costo",
      title: "¿Cuánto cuesta trabajar con HIDDEAL?",
      content: "Tenemos planes escalables según el tamaño y necesidades de tu clínica. Podemos diseñar una propuesta a tu medida después de un diagnóstico inicial gratuito.",
    },
    {
      id: "tiempo",
      title: "¿Cuánto tiempo tarda en ver resultados?",
      content: "La mayoría de nuestras clínicas comienzan a ver un flujo constante de pacientes entre 30 y 60 días, dependiendo del tipo de clínica y estrategia aplicada.",
    },
    {
      id: "personal",
      title: "¿Necesito contratar personal adicional?",
      content: "No, nuestros sistemas automatizados de mensajes, agenda y seguimiento permiten que tu equipo actual gestione los pacientes sin sobrecarga.",
    },
    {
      id: "tipo-clinica",
      title: "¿Solo trabajan con clínicas médicas?",
      content: "No. También trabajamos con clínicas dentales, estéticas y especializadas en distintas áreas de la salud.",
    },
    {
      id: "no-respuesta",
      title: "¿Qué pasa si mis pacientes no responden?",
      content: "Implementamos estrategias de seguimiento y recordatorios automáticos para maximizar la conversión de interesados en citas agendadas.",
    },
  ];

  const services = [
    { id: "google-maps", name: "Google Maps", icon: <MapPin className="h-5 w-5" />, description: "Optimizamos tu perfil para que tu clínica aparezca cuando las personas buscan servicios como el tuyo en tu zona." },
    { id: "fotos-videos", name: "Fotos y Videos", icon: <Camera className="h-5 w-5" />, description: "Creamos fotos y videos reales y profesionales de tu clínica para transmitir confianza." },
    { id: "sistema-reseñas", name: "Sistema de Reseñas", icon: <Search className="h-5 w-5" />, description: "Implementamos un sistema automático para conseguir más reseñas positivas en Google." },
    { id: "anuncios-meta", name: "Anuncios Meta", icon: <Globe className="h-5 w-5" />, description: "Creamos anuncios estratégicos que llegan a personas interesadas en tus servicios." },
    { id: "pagina-web", name: "Página Web", icon: <LayoutDashboard className="h-5 w-5" />, description: "Desarrollamos una página clara y optimizada para convertir visitas en mensajes o citas." },
    { id: "branding-basico", name: "Branding Básico", icon: <Database className="h-5 w-5" />, description: "Unificamos colores, tipografías y estilo visual para que tu clínica se vea profesional." },
    { id: "recepcionista-virtual", name: "Recepcionista Virtual", icon: <Smartphone className="h-5 w-5" />, description: "Implementamos un sistema que atiende llamadas y agenda citas automáticamente." },
    { id: "chatbot-automatizado", name: "Chatbot Automatizado", icon: <MessageSquareOff className="h-5 w-5" />, description: "Creamos un chatbot que responde preguntas y guía a los interesados hasta agendar." },
  ];

  return (
    <main className="min-h-screen bg-black text-white selection:bg-primary selection:text-white">
      
      {/* HERO SECTION */}
      <section className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden">
        <EtheralShadow 
          color="rgba(75, 0, 129, 0.6)" 
          animation={{ scale: 100, speed: 100 }} 
          noise={{ opacity: 0.5, scale: 1.2 }}
        >
          <div className="container mx-auto px-6 relative z-20 flex flex-col items-center text-center gap-8 max-w-4xl">
            <div className="flex items-center gap-2 mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="h-px w-8 bg-primary/50"></div>
                <span className="text-primary font-medium tracking-widest uppercase text-sm">HIDDEAL Agency</span>
                <div className="h-px w-8 bg-primary/50"></div>
            </div>
            
            <h1 className="text-5xl sm:text-7xl font-bold tracking-tight text-white leading-[1.1] animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-100">
              Transformamos tu clínica en un <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">imán de pacientes</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-gray-400 max-w-2xl leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-200">
              No más citas vacías ni dependencia del azar. Nosotros hacemos que tu clínica crezca de manera predecible mediante sistemas operativos y estratégicos.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mt-8 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-300">
              <a 
                href="#agendar" 
                className="px-8 py-4 bg-primary text-white font-medium rounded-full hover:bg-primary/90 transition-all flex items-center gap-2 group"
              >
                Agendar diagnóstico gratis
                <ArrowUpRight className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
              <a 
                href="#que-hacemos" 
                className="px-8 py-4 bg-transparent border border-white/20 text-white font-medium rounded-full hover:bg-white/5 transition-all"
              >
                Ver servicios
              </a>
            </div>
          </div>
        </EtheralShadow>
      </section>

      {/* PROBLEMS SECTION */}
      <section className="py-24 px-6 bg-black relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight">Problemas Reales</h2>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg">
              Entendemos que dirigir una clínica es difícil cuando te enfrentas a estos obstáculos diarios.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {problems.map((problem, i) => (
              <SpotlightCard key={i} className="p-8 h-full flex flex-col gap-4 bg-neutral-900/50 border-neutral-800">
                <div className="h-12 w-12 flex items-center justify-center rounded-lg bg-neutral-800 border border-neutral-700">
                  {problem.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">{problem.title}</h3>
                  <p className="text-sm text-neutral-400 leading-relaxed">
                    {problem.description}
                  </p>
                </div>
              </SpotlightCard>
            ))}
          </div>
        </div>
      </section>

      {/* WHAT WE DO & SERVICES */}
      <section id="que-hacemos" className="py-24 px-6 border-t border-white/5 bg-neutral-950">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div className="sticky top-24">
            <span className="text-primary font-medium tracking-widest uppercase text-sm mb-4 block">Qué hacemos</span>
            <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight tracking-tight">
              Construimos sistemas, no solo campañas.
            </h2>
            <p className="text-gray-400 text-lg mb-8 leading-relaxed">
              HIDDEAL crea un proceso completo para que personas interesadas lleguen a la clínica, los mensajes no se pierdan y las preguntas se conviertan en citas.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {services.map((service, i) => (
                <button 
                  key={i} 
                  onClick={() => setLocation(`/servicio/${service.id}`)}
                  className="flex items-center gap-3 p-3 rounded-lg border border-white/5 bg-white/5 hover:bg-primary/20 hover:border-primary/50 transition-all group text-left w-full"
                >
                  <div className="text-primary group-hover:scale-110 transition-transform">{service.icon}</div>
                  <span className="text-sm font-medium text-gray-200 group-hover:text-white transition-colors">{service.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div id="proceso" className="relative">
             {/* Decorative element */}
             <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-purple-500/20 rounded-2xl blur-2xl opacity-50" />
             <div className="relative bg-black/80 border border-white/10 rounded-2xl p-6 sm:p-8 backdrop-blur-sm">
                <h3 className="text-2xl font-semibold mb-6">Nuestro Proceso</h3>
                <UniqueAccordion items={processItems} />
             </div>
          </div>
        </div>
      </section>

      {/* CTA INTERSTITIAL */}
      <div id="agendar">
        <LetsWorkTogether />
      </div>

      {/* FAQs */}
      <section className="py-24 px-6 bg-black border-t border-white/5">
        <FaqsSection questions={faqs} />
      </section>

      <Footer />
    </main>
  );
}
